package com.example.blockblastassist

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

class AssistService : AccessibilityService() {
    companion object {
        @Volatile var enabled = false
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!enabled) return
        // Punto di estensione: riconoscimento della griglia e calcolo della miglior mossa.
        // Questa demo non invia tocchi al gioco automaticamente.
    }

    override fun onInterrupt() {
        enabled = false
    }

    fun tap(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 30))
            .build()
        dispatchGesture(gesture, null, null)
    }
}
