package com.example.blockblastassist

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val title = TextView(this).apply {
            text = "BLOCK BLAST ASSIST"
            textSize = 24f
            setPadding(24, 40, 24, 20)
        }
        val info = TextView(this).apply {
            text = "Apri Accessibilità e abilita Block Blast Assist.\n\nAUTO PLAY è disattivato finché non premi Avvia."
            textSize = 16f
            setPadding(24, 10, 24, 20)
        }
        val settings = Button(this).apply {
            text = "Apri Accessibilità"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        val start = Button(this).apply {
            text = "AVVIA ASSISTENTE"
            setOnClickListener { AssistService.enabled = true }
        }
        val stop = Button(this).apply {
            text = "STOP"
            setOnClickListener { AssistService.enabled = false }
        }
        val credit = TextView(this).apply {
            text = "by andre_sus29"
            textSize = 14f
            setPadding(24, 28, 24, 24)
            alpha = 0.8f
        }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(title)
            addView(info)
            addView(settings)
            addView(start)
            addView(stop)
            addView(credit)
        })
    }
}
