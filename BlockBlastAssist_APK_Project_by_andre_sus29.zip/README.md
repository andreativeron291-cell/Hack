# Block Blast Assist

Progetto Android di base per un assistente personale.

## Cosa contiene
- pannello di controllo
- collegamento alle impostazioni Accessibilità
- servizio Android predisposto per leggere eventi e, con autorizzazione, usare gesture
- modalità START/STOP

## Nota
La parte di riconoscimento della griglia e il motore per scegliere la miglior combinazione sono lasciati come componente successivo. Il progetto non modifica l'app ufficiale né aggira account o protezioni.
