# Come ottenere l'APK

## Metodo semplice: GitHub Actions
1. Crea un repository GitHub vuoto.
2. Carica tutti i file di questo progetto.
3. Apri la scheda **Actions**.
4. Avvia **Build APK** con **Run workflow**.
5. Al termine apri gli **Artifacts** e scarica `BlockBlastAssist-debug`.
6. Estrai lo ZIP e installa `app-debug.apk` sul telefono.

## Metodo Android Studio
Apri la cartella del progetto in Android Studio e usa:
Build -> Build Bundle(s) / APK(s) -> Build APK(s)

Il progetto contiene già il servizio Accessibilità e il pannello START/STOP.
